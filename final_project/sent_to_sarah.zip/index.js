const serverURL = 'https://alyssazhong2021.github.io/eecs130-coursework/queer_eye.json';

const getData = () => {
    fetch(serverURL)
        .then(response => response.json())
        .then(loadCards);
};

const loadCards = (list) => {
    document.querySelector('.cards').innerHTML = '';
    // load new ones (based on photos list)
    for (dictionary of list) {
        const template = `
            <li class="card">
                <div class="rank">${dictionary.rank}</div>
                <div class="name">${dictionary.name}</div>
                <div class="season">${dictionary.season}</div>
                <div class="episode">${dictionary.episode}</div>
                <div class="image" style="background-image:url('${dictionary.image}')"></div>
            </li>`;
        document.querySelector('.cards').innerHTML += template;
    }
    // initCarousel();
};

getData();
